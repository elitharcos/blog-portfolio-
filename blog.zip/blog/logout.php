<?php

setcookie("name","", time()-36000, "/");
header("Location: index.php");

?>