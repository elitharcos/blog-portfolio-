<?php

    require "config.php";

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css?v=1.5">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <title>Főoldal</title>
    </head>
    <body>
        <div class="topnav" id="nav-box">
        </div>
        <div class="center">
            <h1><i><?= $megrendelnev ?> Blog</i></h1>
            <div class="profilepicdiv">
                <p class="profilepictextwelcome"> Üdvözöllek a blogomban és remélem élvezni fogod az itt töltött időt! </p>
                <img class="profilepic" src="pfp.png"><br>
                <br>
            </div>
            <div class="profilepictextwelcomediv">
                <p class="profilepictext"><?= $megrendelnev ?></p><br><br><br>
            </div>
            <div>
                <?php
                    $lekerdezes = "SELECT * FROM posts ORDER BY timeofposting DESC";
                    $result = $conn->query($lekerdezes);
                    $data = $result->fetch_assoc();
                    if ($data){
                ?>
                <div class="postnameCSS">
                    <h2> <?= $data['postname']; ?> </h2>
                </div>
                <div class="posttextCSS">
                    <p> <?= $data['posttext']; ?><br><br> </p>
                </div>
                <?php } ?>
            </div>
        </div>
        <script src="navbar.js?v=1.6"></script>
    </body>
</html>