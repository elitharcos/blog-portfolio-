<?php

    require "config.php";

    if  (isset($_POST['regist-btn'])){
        echo "<script>console.log("."asd".")</script>";
        $lekerdezes = "SELECT * from user WHERE '$_POST[username]' = username";
        $result = $conn->query($lekerdezes);
        //echo "<script>console.log(".strval($result).")</script>";
        if (mysqli_num_rows($result)==0){
            $conn->query("INSERT INTO user VALUES (id, '$_POST[username]', '$_POST[password]', '$_POST[email]')");
            setcookie("name",$_POST["username"], time()+3600, "/");
            header("location: index.php");
        }
        $message = strval($result->fetch_assoc()['id']);
        echo "<script>console.log('$message');</script>";
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css?v=1.7">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <title>Főoldal</title>
    </head>
    <body>
        <div class="topnav" id="nav-box">
        </div>
        <div class="center">
            <h1><i><?= $megrendelnev ?> Blog Regiszrtrációs Oldal</i></h1><br>
            <div>
                <form method="post" action="regist.php">
                    <input style="color: black" type="email" name="email" placeholder="email address"><br><br>
                    <input style="color: black" type="text" name="username" placeholder="Felhasználónév"><br><br>
                    <input style="color: black" type="password" name="password" placeholder="Jelszó"><br><br>
                    <input style="color: black" type="submit" name="regist-btn" value="Regisztrálok!">
                </form>
            </div>
        </div>
        <script src="navbar.js?v=1.6"></script>
    </body>
</html>