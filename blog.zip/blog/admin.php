<?php

    require "config.php";

    if (isset($_POST['post-btn'])){
        $inputtext = nl2br($_POST["posttext"]);
        $inputname = $_POST['postname'];
        $conn->query("INSERT INTO posts (postname,posttext) VALUES ('$inputname','$inputtext')");
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css?v=1.5">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <title>Posztolás Oldal</title>
    </head>
    <body>
        <div class="topnav" id="nav-box">
        </div>
        <div class="center">
            <h1><i>Posztolás</i></h1>
            <div>
                <form method="post" action="admin.php">
                    <label for="text-post">Poszt neve:</label><br>
                    <input style="color: black" type="text" placeholder="Poszt neve" name="postname"></input><br><br>
                    <label for="textarea-post">Szöveges poszt (több sorban):</label><br>
                    <textarea placeholder="Poszt írása" name="posttext"></textarea><br><br>
                    <input style="color: black" type="submit" name="post-btn" value="Posztolok!">
                </form>
            </div>
        </div>
        <script src="navbar.js?v=1.6"></script>
    </body>
</html>