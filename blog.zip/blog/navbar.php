<?php

    require "config.php";

    if (isset($_COOKIE['name'])){
        echo '<nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                <a class="navbar-brand" href="index.php">'.$megrendelnev.' Blog</a>
                </div>
                <ul class="nav navbar-nav">
                    <li><a href="index_allposts.php">Összes poszt</a></li>'; 
                    if ($_COOKIE['name']==$megrendelnev){
                        echo '
                    <li><a href="admin.php">Admin</a></li>
                    <li><a href="messages.php">Követők üzenetei</a></li>'; } else {
                        echo '<li><a href="messages.php">Üzenet küldése</a></li>';
                    }
                    echo '
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="logout.php">Kijelentkezés</a></li>
                </ul>
            </div>
        </nav>';
    }else{
        echo '<nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                <a class="navbar-brand" href="index.php">'.$megrendelnev.' Blog</a>
                </div>
                <ul class="nav navbar-nav">
                    <li><a href="index_allposts.php">Összes poszt</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="login.php">Bejelentkezés</a></li>
                    <li><a href="regist.php">Regisztrálás</a></li>
                </ul>
            </div>
        </nav>';
    }
    echo '<script src="background.js?v=1.0"></script>';

?>