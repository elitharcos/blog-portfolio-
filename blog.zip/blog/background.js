let hue1 = 0;
let hue2 = 240;

function backgroundUpdate(){
    hue1 = (hue1 + 1) % 360;
    hue2 = (hue2 + 1) % 360;
    
    document.body.style.background = `conic-gradient(hsl(${hue1}, 100%, 33%), hsl(${hue2}, 100%, 33%),hsl(${hue1}, 100%, 33%)`;
    document.getElementsByClassName("center")[0].style.boxShadow = `0 0 2vw hsl(${(hue1 + 180) % 360}, 100%, 33%), 0 0 2vw hsl(${(hue2 + 180) % 360}, 100%, 33%)`;
}

setInterval(backgroundUpdate,50); 