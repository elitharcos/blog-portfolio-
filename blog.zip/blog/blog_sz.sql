-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Jan 20. 21:40
-- Kiszolgáló verziója: 10.4.25-MariaDB
-- PHP verzió: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `blog_sz`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sendername` varchar(1000) COLLATE utf8_hungarian_ci NOT NULL,
  `message` varchar(1000) COLLATE utf8_hungarian_ci NOT NULL,
  `timeofsending` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `messages`
--

INSERT INTO `messages` (`id`, `sendername`, `message`, `timeofsending`) VALUES
(18, 'asd', 'From: asd@asd<br><br>Hello there!\r\nGeneral Kenobi!', '2024-01-20 20:34:04');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `postname` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `posttext` varchar(5000) COLLATE utf8_hungarian_ci NOT NULL,
  `timeofposting` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `posts`
--

INSERT INTO `posts` (`id`, `postname`, `posttext`, `timeofposting`) VALUES
(10, 'Burgonya előzményei', 'A burgonya (Solanum tuberosum), ismertebb nevén a krumpli a burgonyafélék (Solanaceae) családjába tartozó növény, amelyet keményítőben gazdag gumójáért termesztenek világszerte.<br />\r\n<br />\r\nPeru és Chile hegyvidékén őshonos, az ott élők körülbelül 7000 éve fogyasztják. Európába a 16. században Pizarro révén került. Magyarországra 1650 körül jöhetett be bajor-osztrák közvetítéssel, de igazi elterjedése II. József magyar király adókedvezményeinek volt köszönhető.<br />\r\n<br />\r\nA krumpli szó bajor-osztrák nyelvterületről érkezett a magyar nyelvbe, míg a burgonya szó etimológiai eredete eddig tisztázatlan.<br />\r\n<br />\r\nBurgonya<br />\r\nA növény hivatalos elnevezése a burgonya, mely eredetileg tájszóként Baranya vármegye egyes területein jelent meg a magyar nyelvben. A burgonya szó etimológiai eredete eddig tisztázatlan. Van olyan vélekedés, mely szerint Burgundia (olaszul: Borgogna, aminek kiejtése kb. „borgonya”) lehetett a névadó.<br />\r\n<br />\r\nKrumpli<br />\r\nA Magyarországra került növény nem Burgundiából származott, hanem német közvetítéssel érkezett, és a bajor-osztrák nyelvjárásokban használt krumpel alapján kapta a krumpli elnevezést. A német szó egyébként – hasonlóan más európai nyelvekhez – a „földi alma” vagy „körte” fordításából keletkezett (grundbirne=földkörte).<br />\r\n<br />\r\nPeru és Chile hegyvidékén őshonos, ott az őslakosok már körülbelül 5000 éve termesztik, de fogyasztása már több mint hétezer évvel ezelőttre tehető. Európába először Pizarro expedíciója hozta el az 1540-es években. A 16-17. században spanyol, portugál kereskedők elterjesztették Ázsiában és Afrikában is. 1588-ban Charles de L’Écluse (Carolus Clusius) híres holland botanikushoz került a burgonya. A magyarországi botanika első mecénása Batthyány Boldizsár, a tudományszeretete miatt a németújvári és szalónaki uradalmain látta vendégül Carolus Clusiust, ekkor került először a krumpli Magyarországra. Azonban még hosszú ideig tartott mire elterjedt az országban. Az 1800-as évektől kezdtek el komolyabban foglalkozni vele, mivel ingyen osztottak szét vetőgumót és II. József magyar király adókedvezménnyel támogatta a termelőket.<br />\r\n<br />\r\nAusztráliába az angolok vitték a 18. században. Ez a legfontosabb termesztett, nem gabonanövény, így több ezer fajtája ismert. Becslések szerint ma világszerte 192 000 km²-en termesztenek burgonyát.', '2024-01-20 02:44:44'),
(11, 'Another One', 'Hmm egy rövidebb poszt', '2024-01-20 02:47:26'),
(12, 'Burgonya előzmények 2', 'A burgonya (Solanum tuberosum), ismertebb nevén a krumpli a burgonyafélék (Solanaceae) családjába tartozó növény, amelyet keményítőben gazdag gumójáért termesztenek világszerte.<br />\r\n<br />\r\nPeru és Chile hegyvidékén őshonos, az ott élők körülbelül 7000 éve fogyasztják. Európába a 16. században Pizarro révén került. Magyarországra 1650 körül jöhetett be bajor-osztrák közvetítéssel, de igazi elterjedése II. József magyar király adókedvezményeinek volt köszönhető.<br />\r\n<br />\r\nA krumpli szó bajor-osztrák nyelvterületről érkezett a magyar nyelvbe, míg a burgonya szó etimológiai eredete eddig tisztázatlan.<br />\r\n<br />\r\nBurgonya<br />\r\nA növény hivatalos elnevezése a burgonya, mely eredetileg tájszóként Baranya vármegye egyes területein jelent meg a magyar nyelvben. A burgonya szó etimológiai eredete eddig tisztázatlan. Van olyan vélekedés, mely szerint Burgundia (olaszul: Borgogna, aminek kiejtése kb. „borgonya”) lehetett a névadó.<br />\r\n<br />\r\nKrumpli<br />\r\nA Magyarországra került növény nem Burgundiából származott, hanem német közvetítéssel érkezett, és a bajor-osztrák nyelvjárásokban használt krumpel alapján kapta a krumpli elnevezést. A német szó egyébként – hasonlóan más európai nyelvekhez – a „földi alma” vagy „körte” fordításából keletkezett (grundbirne=földkörte).<br />\r\n<br />\r\nPeru és Chile hegyvidékén őshonos, ott az őslakosok már körülbelül 5000 éve termesztik, de fogyasztása már több mint hétezer évvel ezelőttre tehető. Európába először Pizarro expedíciója hozta el az 1540-es években. A 16-17. században spanyol, portugál kereskedők elterjesztették Ázsiában és Afrikában is. 1588-ban Charles de L’Écluse (Carolus Clusius) híres holland botanikushoz került a burgonya. A magyarországi botanika első mecénása Batthyány Boldizsár, a tudományszeretete miatt a németújvári és szalónaki uradalmain látta vendégül Carolus Clusiust, ekkor került először a krumpli Magyarországra. Azonban még hosszú ideig tartott mire elterjedt az országban. Az 1800-as évektől kezdtek el komolyabban foglalkozni vele, mivel ingyen osztottak szét vetőgumót és II. József magyar király adókedvezménnyel támogatta a termelőket.<br />\r\n<br />\r\nAusztráliába az angolok vitték a 18. században. Ez a legfontosabb termesztett, nem gabonanövény, így több ezer fajtája ismert. Becslések szerint ma világszerte 192 000 km²-en termesztenek burgonyát.', '2024-01-20 16:28:12');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`) VALUES
(10, 'Szabolcs', 'asd', 'asd@asd'),
(11, 'asd', 'asd', 'asd@asd'),
(12, 'asd1', 'asd1', 'asd@asd');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT a táblához `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT a táblához `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
