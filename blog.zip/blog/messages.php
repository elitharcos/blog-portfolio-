<?php

    require "config.php";

    if (isset($_POST['message-btn'])){
        if (isset($_COOKIE['name'])){
            $sentmessage = "From: ".$_POST['emailname']."<br><br>"."$_POST[messagetext]";
            $conn->query("INSERT INTO messages (sendername,message) VALUES ('$_COOKIE[name]','$sentmessage')");
            header("Location: messages.php");
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css?v=1.3">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <title>Főoldal</title>
    </head>
    <body>
        <div class="topnav" id="nav-box">
        </div>
        <div class="center">
            <h1><i><?= $megrendelnev ?> Blog Üzenő Felület</i></h1>
            <div class="profilepicdiv">
                <p class="profilepictextwelcome"> Üdvözöllek a blog üzenő felületén! </p>
            </div>
            <div>
                <?php
                    if ($_COOKIE['name']==$megrendelnev){
                    $lekerdezes = "SELECT * FROM messages ORDER BY timeofsending DESC";
                    $result = $conn->query($lekerdezes);
                    while($data = $result->fetch_assoc()){
                ?>
                <div class="postnameCSS">
                    <h2> <?= $data['sendername']; ?> </h2>
                </div>
                <div class="posttextCSS">
                    <p> <?= $data['message']; ?><br><br> </p>
                </div>
                <?php } } else { ?>
                    <?php
                        $lekerdezes = "SELECT * FROM messages WHERE sendername='$_COOKIE[name]' ORDER BY timeofsending DESC";
                        $result = $conn->query($lekerdezes);
                        $data = $result->fetch_assoc();
                    ?>
                    <h1><i> Utolsó Üzeneted: </i></h1>
                    <div class="postnameCSS">
                        <h2> <?= $data['sendername']; ?> </h2>
                    </div>
                    <div class="posttextCSS">
                        <p> <?= $data['message']; ?><br><br> </p>
                    </div>
                    <div>
                        <form method="post" action="messages.php">
                            <label for="text-post">Te emailed:</label><br>
                            <input style="color: black" type="email" placeholder="email@address" name="emailname"></input><br><br>
                            <label for="textarea-post">Üzenet <?= $megrendelnev ?> Blogolóhoz:</label><br>
                            <textarea placeholder="Poszt írása" name="messagetext"></textarea><br><br>
                            <input style="color: black" type="submit" name="message-btn" value="Üzenet küldése!">
                        </form>
                    </div>
                    <br><br><h1><i> Összes Üzeneted: </i></h1>
                    <?php 
                        $result = $conn->query($lekerdezes);
                        while($data = $result->fetch_assoc()){
                    ?>
                    <div class="postnameCSS">
                        <h2> <?= $data['sendername']; ?> </h2>
                    </div>
                    <div class="posttextCSS">
                        <p> <?= $data['message']; ?><br><br> </p>
                    </div>
                <?php } } ?>
            </div>
        </div>
        <script src="navbar.js?v=1.6"></script>
    </body>
</html>