<?php

    require "config.php";

    if  (isset($_POST['login-btn'])){
        echo "<script>console.log("."asd".")</script>";
        $lekerdezes = "SELECT * from user WHERE '$_POST[username]' = username";
        $result = $conn->query($lekerdezes);
        //echo "<script>console.log(".strval($result).")</script>";
        if (mysqli_num_rows($result)!=0){
            $data = $result->fetch_assoc();
            setcookie("name", $data['username'], time()+3600, "/", null, true, true);
            header("location: index.php");
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/styles.css?v=1.7">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <title>Főoldal</title>
    </head>
    <body>
        <div class="topnav" id="nav-box">
        </div>
        <div class="center">
            <h1><i><?= $megrendelnev ?> Blog Belépési Oldal</i></h1><br>
            <div>
                <form method="post" action="login.php">
                    <input style="color: black" type="text" name="username" placeholder="Felhasználónév"><br><br>
                    <input style="color: black" type="password" name="password" placeholder="Jelszó"><br><br>
                    <input style="color: black" type="submit" name="login-btn" value="Belépek!">
                </form>
            </div>
        </div>
        <script src="navbar.js?v=1.6"></script>
    </body>
</html>